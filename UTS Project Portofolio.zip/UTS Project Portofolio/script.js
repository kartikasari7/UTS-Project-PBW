document.addEventListener("DOMContentLoaded", function () {
    const ctaButtons = document.querySelectorAll(".cta");
    ctaButtons.forEach(button => {
        button.addEventListener("click", function () {
            alert("Fitur ini masih dalam pengembangan!");
        });
    });
});

function kembaliKeBeranda() {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}
